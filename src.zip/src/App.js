import logo from './logo.svg';
import './App.css';
import Cart from './Components/Cart'

function App() {
  return (
    <div className="App">
      <Cart/>
    </div>
  );
}

export default App;
